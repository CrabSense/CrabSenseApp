import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../config/app_env.dart';
import '../data/mock_iot_devices_data.dart';
import '../models/iot_device.dart';
import '../models/auth_models.dart';

class IotDeviceService extends IoTDeviceService {
  IotDeviceService({required super.session});

  String _search = '';
  String _category = 'Tất cả';
  String? _selectedDeviceId;
  bool _emergencyStop = false;

  List<IotDevice> _mockDevices = [];
  List<IotAutomationRule> _rules = [];

  void setSearch(String value) {
    _search = value;
    notifyListeners();
  }

  String get category => _category;

  void setCategory(String cat) {
    _category = cat;
    notifyListeners();
  }

  IotDevice? get selectedDevice {
    if (_selectedDeviceId == null) return null;
    final list = _getMockDevices();
    final idx = list.indexWhere((d) => d.id == _selectedDeviceId);
    return idx >= 0 ? list[idx] : null;
  }

  void selectDevice(String id) {
    _selectedDeviceId = _selectedDeviceId == id ? null : id;
    notifyListeners();
  }

  List<IotDevice> get filteredIotDevices {
    var list = _getMockDevices();
    if (_category != 'Tất cả') {
      list = list.where((d) => d.typeLabel.contains(_category)).toList();
    }
    if (_search.isNotEmpty) {
      final q = _search.toLowerCase();
      list = list.where((d) =>
          d.name.toLowerCase().contains(q) ||
          d.typeLabel.toLowerCase().contains(q)).toList();
    }
    return list;
  }

  List<IotDevice> _getMockDevices() {
    if (_mockDevices.isEmpty) {
      _mockDevices = MockIotDevicesData.devices();
    }
    return _mockDevices;
  }

  IotDeviceOverview get overview => MockIotDevicesData.overview;
  IotDeviceKpi get kpi => MockIotDevicesData.kpi;
  List<IotActivityLog> get activityLogs => MockIotDevicesData.activityLogs();
  List<IotScheduleEntry> get schedule => MockIotDevicesData.defaultSchedule();
  List<IotCalendarBlock> get calendarBlocks => MockIotDevicesData.calendarBlocks();
  IotDeviceStats get stats => MockIotDevicesData.deviceStats;
  String get aiInsight => MockIotDevicesData.aiInsight;
  String get aiRecommendation => MockIotDevicesData.aiRecommendation;
  int get coreCpuPercent => MockIotDevicesData.coreCpuPercent;
  int get zigbeeSignalPercent => MockIotDevicesData.zigbeeSignalPercent;
  List<IotDeviceAlert> get alerts => MockIotDevicesData.systemAlerts();

  List<IotAutomationRule> get rules {
    if (_rules.isEmpty) {
      _rules = MockIotDevicesData.automationRules();
    }
    return _rules;
  }

  bool get emergencyStop => _emergencyStop;

  void emergencyStopAll() {
    _emergencyStop = true;
    notifyListeners();
  }

  void resetEmergency() {
    _emergencyStop = false;
    notifyListeners();
  }

  void togglePower(String id) {
    final list = _getMockDevices();
    final idx = list.indexWhere((d) => d.id == id);
    if (idx >= 0) {
      _mockDevices[idx] = list[idx].copyWithTogglePower();
      notifyListeners();
    }
  }

  void toggleMode(String id) {
    final list = _getMockDevices();
    final idx = list.indexWhere((d) => d.id == id);
    if (idx >= 0) {
      final d = list[idx];
      final next = d.mode == IotControlMode.auto
          ? IotControlMode.manual
          : IotControlMode.auto;
      _mockDevices[idx] = d.copyWithMode(next);
      notifyListeners();
    }
  }

  void setMode(String id, IotControlMode mode) {
    final list = _getMockDevices();
    final idx = list.indexWhere((d) => d.id == id);
    if (idx >= 0) {
      _mockDevices[idx] = list[idx].copyWithMode(mode);
      notifyListeners();
    }
  }

  void fixNow(String id) => notifyListeners();
  void testDevice(String id) => notifyListeners();
  void triggerWash(String id) => notifyListeners();
  void feedNow(String id) => notifyListeners();

  void setValveOpen(String id, int percent) => notifyListeners();

  void toggleRule(String ruleId) {
    final idx = _rules.indexWhere((r) => r.id == ruleId);
    if (idx >= 0) {
      _rules[idx] = _rules[idx].copyWith(enabled: !_rules[idx].enabled);
      notifyListeners();
    }
  }
}

class IoTDeviceService extends ChangeNotifier {
  IoTDeviceService({required AuthSession session}) : _session = session;

  AuthSession _session;

  String get selectedFarmName => _session.selectedFarm.name;
  String get selectedFarmId => _session.selectedFarm.id;

  void updateSession(AuthSession session) {
    _session = session;
    _devices = [];
    _error = null;
    notifyListeners();
  }

  var _loading = false;
  String? _error;
  List<IoTDevice> _devices = [];
  String? _selectedBoxId;

  bool get loading => _loading;
  String? get error => _error;
  List<IoTDevice> get devices => List.unmodifiable(_devices);
  String? get selectedBoxId => _selectedBoxId;

  List<IoTDevice> get filteredDevices {
    if (_selectedBoxId == null) return _devices;
    return _devices.where((d) => d.boxId == _selectedBoxId).toList();
  }

  void selectBox(String? boxId) {
    _selectedBoxId = boxId;
    notifyListeners();
  }

  Future<void> loadDevices({String? farmId}) async {
    _loading = true;
    _error = null;
    notifyListeners();

    try {
      final token = _session.token;

      final fid = farmId ?? _session.selectedFarm.id;

      final url = Uri.parse('${AppEnv.cloudApiUrl}/api/devices?farmId=$fid');
      final res = await http.get(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
          'X-Farm-Id': fid,
        },
      );

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['ok'] == false) {
          _error = (json['error'] ?? json['Error'])?.toString() ?? 'Lỗi API';
          _devices = [];
        } else {
          final raw = json['devices'] ?? json['Devices'];
          if (raw is List) {
            _devices = raw
                .whereType<Map>()
                .map((d) => IoTDevice.fromJson(Map<String, dynamic>.from(d)))
                .toList();
          } else {
            _devices = [];
          }
          _error = null;
        }
      } else {
        _error = 'HTTP ${res.statusCode}: ${res.body}';
      }
    } catch (e) {
      _error = '$e';
    } finally {
      _loading = false;
      Future.microtask(() {
        if (hasListeners) notifyListeners();
      });
    }
  }

  /// Tải thiết bị thuộc các hộp trên dãy (Quản lý hộp) hoặc một hộp.
  Future<void> loadDevicesForBoxes(
    List<String> boxIds, {
    String? farmId,
  }) async {
    if (boxIds.isEmpty) {
      _devices = [];
      _error = null;
      _loading = false;
      notifyListeners();
      return;
    }
    if (boxIds.length == 1) {
      await loadDevicesByBox(boxIds.first);
      return;
    }

    await loadDevices(farmId: farmId);
    final allowed = boxIds.toSet();
    _devices = _devices
        .where((d) => d.boxId != null && allowed.contains(d.boxId))
        .toList();
    notifyListeners();
  }

  Future<void> loadDevicesByBox(String boxId) async {
    _loading = true;
    _error = null;
    notifyListeners();

    try {
      final token = _session.token;

      final url =
          Uri.parse('${AppEnv.cloudApiUrl}/api/boxes/$boxId/devices');
      final res = await http.get(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        final deviceList = json['devices'] as List;
        _devices = deviceList
            .map((d) => IoTDevice.fromJson(d as Map<String, dynamic>))
            .toList();
        _error = null;
      } else {
        _error = 'HTTP ${res.statusCode}: ${res.body}';
      }
    } catch (e) {
      _error = '$e';
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<String?> getNextDeviceCode({String? farmId}) async {
    try {
      final token = _session.token;

      final fid = farmId ?? _session.selectedFarm.id;

      final url =
          Uri.parse('${AppEnv.cloudApiUrl}/api/devices/next-code?farmId=$fid');
      final res = await http.get(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        return json['code'] as String?;
      }
    } catch (e) {
      debugPrint('Error getting next device code: $e');
    }
    return null;
  }

  Future<IoTDevice?> createDevice(
    UpsertDeviceRequest request, {
    String? farmId,
  }) async {
    try {
      final token = _session.token;

      final fid = farmId ?? _session.selectedFarm.id;

      final url = Uri.parse('${AppEnv.cloudApiUrl}/api/devices?farmId=$fid');
      final res = await http.post(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode(request.toJson()),
      );

      if (res.statusCode == 201) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        final raw = json['device'] ?? json['Device'];
        if (raw is! Map) return null;
        final device =
            IoTDevice.fromJson(Map<String, dynamic>.from(raw));
        _devices.add(device);
        notifyListeners();
        return device;
      } else {
        _error = 'HTTP ${res.statusCode}: ${res.body}';
        notifyListeners();
      }
    } catch (e) {
      _error = '$e';
      notifyListeners();
    }
    return null;
  }

  Future<IoTDevice?> updateDevice(
    String deviceId,
    UpsertDeviceRequest request,
  ) async {
    try {
      final token = _session.token;

      final url = Uri.parse('${AppEnv.cloudApiUrl}/api/devices/$deviceId');
      final res = await http.put(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode(request.toJson()),
      );

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        final raw = json['device'] ?? json['Device'];
        if (raw is! Map) return null;
        final device =
            IoTDevice.fromJson(Map<String, dynamic>.from(raw));
        final index = _devices.indexWhere((d) => d.id == deviceId);
        if (index >= 0) {
          _devices[index] = device;
          notifyListeners();
        }
        return device;
      } else {
        _error = 'HTTP ${res.statusCode}: ${res.body}';
        notifyListeners();
      }
    } catch (e) {
      _error = '$e';
      notifyListeners();
    }
    return null;
  }

  Future<bool> deleteDevice(String deviceId) async {
    try {
      final token = _session.token;

      final url = Uri.parse('${AppEnv.cloudApiUrl}/api/devices/$deviceId');
      final res = await http.delete(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (res.statusCode == 204) {
        _devices.removeWhere((d) => d.id == deviceId);
        notifyListeners();
        return true;
      } else {
        _error = 'HTTP ${res.statusCode}: ${res.body}';
        notifyListeners();
      }
    } catch (e) {
      _error = '$e';
      notifyListeners();
    }
    return false;
  }
}
