import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../config/app_env.dart';
import '../models/camera_device.dart';
import '../models/auth_models.dart';

class CameraDeviceService extends ChangeNotifier {
  CameraDeviceService({required AuthSession session}) : _session = session;

  AuthSession _session;

  void updateSession(AuthSession session) {
    _session = session;
    notifyListeners();
  }

  var _loading = false;
  String? _error;
  List<CameraDevice> _cameras = [];
  String? _selectedBoxId;
  String? _selectedGatewayId;

  bool get loading => _loading;
  String? get error => _error;
  List<CameraDevice> get cameras => List.unmodifiable(_cameras);
  String? get selectedBoxId => _selectedBoxId;
  String? get selectedGatewayId => _selectedGatewayId;

  List<CameraDevice> get filteredCameras {
    if (_selectedBoxId == null) return _cameras;
    return _cameras.where((c) => c.boxId == _selectedBoxId).toList();
  }

  void selectBox(String? boxId) {
    _selectedBoxId = boxId;
    notifyListeners();
  }

  void selectGateway(String? gatewayId) {
    _selectedGatewayId = gatewayId;
    notifyListeners();
  }

  Future<void> loadCameras({String? gatewayId}) async {
    _loading = true;
    _error = null;
    notifyListeners();

    try {
      final token = _session.token;
      final gid = gatewayId ?? _selectedGatewayId;

      if (gid == null) {
        _error = 'gatewayId is required';
        return;
      }

      final url = Uri.parse('${AppEnv.cloudApiUrl}/api/cameras?gatewayId=$gid');
      final res = await http.get(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        final cameraList = json['cameras'] as List;
        _cameras = cameraList
            .map((c) => CameraDevice.fromJson(c as Map<String, dynamic>))
            .toList();
        _error = null;
      } else {
        _error = 'HTTP ${res.statusCode}: ${res.body}';
      }
    } catch (e) {
      _error = '$e';
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  /// Tải camera thuộc các hộp trên dãy (Quản lý hộp) hoặc một hộp (chi tiết hộp).
  Future<void> loadCamerasForBoxes(
    List<String> boxIds, {
    String? gatewayId,
  }) async {
    if (boxIds.isEmpty) {
      _cameras = [];
      _error = null;
      _loading = false;
      notifyListeners();
      return;
    }
    if (boxIds.length == 1) {
      await loadCamerasByBox(boxIds.first);
      return;
    }

    _loading = true;
    _error = null;
    notifyListeners();

    try {
      final token = _session.token;
      final gid = gatewayId ?? _selectedGatewayId;
      if (gid == null) {
        _error = 'gatewayId is required';
        return;
      }

      final url = Uri.parse('${AppEnv.cloudApiUrl}/api/cameras?gatewayId=$gid');
      final res = await http.get(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        final cameraList = json['cameras'] as List;
        final allowed = boxIds.toSet();
        _cameras = cameraList
            .map((c) => CameraDevice.fromJson(c as Map<String, dynamic>))
            .where((c) => c.boxId != null && allowed.contains(c.boxId))
            .toList();
        _error = null;
      } else {
        _error = 'HTTP ${res.statusCode}: ${res.body}';
      }
    } catch (e) {
      _error = '$e';
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> loadCamerasByBox(String boxId) async {
    _loading = true;
    _error = null;
    notifyListeners();

    try {
      final token = _session.token;

      final url =
          Uri.parse('${AppEnv.cloudApiUrl}/api/boxes/$boxId/cameras');
      final res = await http.get(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        final cameraList = json['cameras'] as List;
        _cameras = cameraList
            .map((c) => CameraDevice.fromJson(c as Map<String, dynamic>))
            .toList();
        _error = null;
      } else {
        _error = 'HTTP ${res.statusCode}: ${res.body}';
      }
    } catch (e) {
      _error = '$e';
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<String?> getNextCameraCode({String? gatewayId}) async {
    try {
      final token = _session.token;
      final gid = gatewayId ?? _selectedGatewayId;

      if (gid == null) return null;

      final url =
          Uri.parse('${AppEnv.cloudApiUrl}/api/cameras/next-code?gatewayId=$gid');
      final res = await http.get(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        return json['code'] as String?;
      }
    } catch (e) {
      debugPrint('Error getting next camera code: $e');
    }
    return null;
  }

  Future<CameraDevice?> createCamera(
    UpsertCameraRequest request, {
    String? gatewayId,
  }) async {
    try {
      final token = _session.token;
      final gid = gatewayId ?? _selectedGatewayId;

      if (gid == null) {
        _error = 'gatewayId is required';
        notifyListeners();
        return null;
      }

      final url = Uri.parse('${AppEnv.cloudApiUrl}/api/cameras?gatewayId=$gid');
      final res = await http.post(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode(request.toJson()),
      );

      if (res.statusCode == 201) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        final camera = CameraDevice.fromJson(json['camera'] as Map<String, dynamic>);
        _cameras.add(camera);
        notifyListeners();
        return camera;
      } else {
        _error = 'HTTP ${res.statusCode}: ${res.body}';
        notifyListeners();
      }
    } catch (e) {
      _error = '$e';
      notifyListeners();
    }
    return null;
  }

  Future<CameraDevice?> updateCamera(
    String cameraId,
    UpsertCameraRequest request,
  ) async {
    try {
      final token = _session.token;

      final url = Uri.parse('${AppEnv.cloudApiUrl}/api/cameras/$cameraId');
      final res = await http.put(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode(request.toJson()),
      );

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        final camera = CameraDevice.fromJson(json['camera'] as Map<String, dynamic>);
        final index = _cameras.indexWhere((c) => c.id == cameraId);
        if (index >= 0) {
          _cameras[index] = camera;
          notifyListeners();
        }
        return camera;
      } else {
        _error = 'HTTP ${res.statusCode}: ${res.body}';
        notifyListeners();
      }
    } catch (e) {
      _error = '$e';
      notifyListeners();
    }
    return null;
  }

  Future<bool> deleteCamera(String cameraId) async {
    try {
      final token = _session.token;

      final url = Uri.parse('${AppEnv.cloudApiUrl}/api/cameras/$cameraId');
      final res = await http.delete(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (res.statusCode == 204) {
        _cameras.removeWhere((c) => c.id == cameraId);
        notifyListeners();
        return true;
      } else {
        _error = 'HTTP ${res.statusCode}: ${res.body}';
        notifyListeners();
      }
    } catch (e) {
      _error = '$e';
      notifyListeners();
    }
    return false;
  }
}
