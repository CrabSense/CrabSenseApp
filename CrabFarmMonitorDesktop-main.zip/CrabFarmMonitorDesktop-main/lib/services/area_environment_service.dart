import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../config/app_env.dart';
import '../models/area_environment_metric.dart';
import '../models/auth_models.dart';

class AreaEnvironmentService extends ChangeNotifier {
  AreaEnvironmentService({required AuthSession session}) : _session = session;

  static const livePollInterval = Duration(seconds: 2);

  AuthSession _session;

  void updateSession(AuthSession session) {
    _session = session;
    _notifyDeferred();
  }

  void _notifyDeferred() => Future.microtask(notifyListeners);

  var _loading = false;
  var _refreshInFlight = false;
  String? _error;
  AreaSensorLatestData? _data;
  DateTime? _lastRefreshedAt;

  Timer? _liveTimer;
  String? _liveAreaId;
  String? _liveBoxId;

  bool get loading => _loading;
  bool get isLiveActive => _liveTimer != null;
  bool get isRefreshing => _refreshInFlight;
  String? get error => _error;
  AreaSensorLatestData? get data => _data;
  DateTime? get lastRefreshedAt => _lastRefreshedAt;
  List<AreaEnvironmentMetric> get metrics => _data?.metrics ?? const [];

  void startLiveRefresh(
    String areaId, {
    Duration interval = livePollInterval,
  }) {
    if (areaId.trim().isEmpty) return;
    if (_liveAreaId == areaId && _liveTimer != null) return;

    stopLiveRefresh(notify: false);
    _liveAreaId = areaId;
    _liveBoxId = null;
    unawaited(loadByArea(areaId));
    _liveTimer = Timer.periodic(interval, (_) {
      if (_liveAreaId == areaId) {
        unawaited(loadByArea(areaId, silent: true));
      }
    });
    _notifyDeferred();
  }

  void startLiveRefreshByBox(
    String boxId, {
    Duration interval = livePollInterval,
  }) {
    if (boxId.trim().isEmpty) return;
    if (_liveBoxId == boxId && _liveTimer != null) return;

    stopLiveRefresh(notify: false);
    _liveBoxId = boxId;
    _liveAreaId = null;
    unawaited(loadByBox(boxId));
    _liveTimer = Timer.periodic(interval, (_) {
      if (_liveBoxId == boxId) {
        unawaited(loadByBox(boxId, silent: true));
      }
    });
    _notifyDeferred();
  }

  void stopLiveRefresh({bool notify = true}) {
    _liveTimer?.cancel();
    _liveTimer = null;
    _liveAreaId = null;
    _liveBoxId = null;
    if (notify) _notifyDeferred();
  }

  Future<void> loadByArea(String areaId, {bool silent = false}) async {
    if (areaId.trim().isEmpty) return;
    await _fetchLatest(
      Uri.parse('${AppEnv.cloudApiUrl}/api/areas/$areaId/sensor-latest'),
      liveKey: areaId,
      silent: silent,
      emptyMessage: 'Chưa có cảm biến / dữ liệu cho khu này',
    );
  }

  /// Chỉ số bể chung khu — hộp kế thừa (inheritedByBox).
  Future<void> loadByBox(String boxId, {bool silent = false}) async {
    if (boxId.trim().isEmpty) return;
    await _fetchLatest(
      Uri.parse('${AppEnv.cloudApiUrl}/api/boxes/$boxId/sensor-latest'),
      liveKey: boxId,
      silent: silent,
      emptyMessage: 'Chưa có chỉ số môi trường khu cho hộp này',
    );
  }

  Future<void> _fetchLatest(
    Uri url, {
    required String? liveKey,
    required bool silent,
    required String emptyMessage,
  }) async {
    if (silent && _refreshInFlight) return;

    if (!silent) {
      _loading = true;
      _error = null;
      _notifyDeferred();
    } else {
      _refreshInFlight = true;
      _notifyDeferred();
    }

    try {
      final res = await http.get(
        url,
        headers: {
          'Authorization': 'Bearer ${_session.token}',
          'Content-Type': 'application/json',
        },
      );

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['ok'] == true && json['data'] != null) {
          _data = AreaSensorLatestData.fromJson(
            json['data'] as Map<String, dynamic>,
          );
          _error = null;
          _lastRefreshedAt = DateTime.now();
        } else if (!silent) {
          _data = null;
          _error = json['error']?.toString() ?? 'Không có dữ liệu';
        }
      } else if (res.statusCode == 404) {
        if (!silent) {
          _data = null;
          _error = emptyMessage;
        }
      } else if (!silent) {
        _data = null;
        _error = 'HTTP ${res.statusCode}';
      }
    } catch (e) {
      if (!silent) {
        _data = null;
        _error = '$e';
      }
    } finally {
      if (silent) {
        _refreshInFlight = false;
      } else {
        _loading = false;
      }
      if (silent && liveKey != null) {
        if (_liveAreaId != liveKey && _liveBoxId != liveKey) return;
      }
      _notifyDeferred();
    }
  }

  void clear() {
    _data = null;
    _error = null;
    _loading = false;
    _notifyDeferred();
  }

  @override
  void dispose() {
    stopLiveRefresh(notify: false);
    super.dispose();
  }
}
