import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../config/app_env.dart';
import '../models/auth_models.dart';
import 'gateway_info_stub.dart'
    if (dart.library.io) 'gateway_info_native.dart';

String _gatewayDisplayName(String hostname) {
  final label = 'Laptop Gateway ($hostname)';
  return label.length > 100 ? label.substring(0, 100) : label;
}

class GatewayService extends ChangeNotifier {
  GatewayService({required AuthSession session}) : _session = session;

  AuthSession _session;
  String? _gatewayId;
  String? _error;
  bool _registered = false;

  String get gatewayId => _gatewayId ?? AppEnv.defaultGatewayId;
  String? get error => _error;
  bool get registered => _registered;

  Future<void>? _heartbeatInFlight;

  void updateSession(AuthSession session) {
    _session = session;
  }

  Future<void> registerHeartbeat() {
    final inFlight = _heartbeatInFlight;
    if (inFlight != null) return inFlight;
    final run = _registerHeartbeatImpl();
    _heartbeatInFlight = run;
    return run.whenComplete(() {
      if (identical(_heartbeatInFlight, run)) {
        _heartbeatInFlight = null;
      }
    });
  }

  Future<void> _registerHeartbeatImpl() async {
    try {
      final info = await getGatewayNativeInfo();
      final hostname = info['hostname'] ?? 'unknown';
      final localIp = info['localIp'] ?? '127.0.0.1';
      final osVersion = info['osVersion'] ?? 'unknown';

      final farmId = _session.selectedFarm.id;
      final url = Uri.parse(
          '${AppEnv.cloudApiUrl}/api/gateways/heartbeat?farmId=$farmId');

      final res = await http.post(
        url,
        headers: {
          'Authorization': 'Bearer ${_session.token}',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'gatewayCode': 'LAPTOP-GW',
          'name': _gatewayDisplayName(hostname),
          'localIp': localIp,
          'osVersion': osVersion,
        }),
      );

      if (res.statusCode == 200 || res.statusCode == 201) {
        final json = jsonDecode(res.body) as Map<String, dynamic>;
        if (json['ok'] == true && json['gateway'] != null) {
          _gatewayId = json['gateway']['id'] as String?;
          _registered = true;
          _error = null;
          debugPrint('Gateway registered: $_gatewayId (IP: $localIp)');
        }
      } else {
        _error = 'HTTP ${res.statusCode}';
        debugPrint('Gateway heartbeat failed: ${res.statusCode} ${res.body}');
      }
    } catch (e) {
      _error = '$e';
      debugPrint('Gateway heartbeat error: $e');
    }
    notifyListeners();
  }
}
