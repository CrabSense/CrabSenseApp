class AreaEnvironmentMetric {
  const AreaEnvironmentMetric({
    required this.label,
    required this.value,
    required this.unit,
    required this.icon,
    required this.status,
    this.sensorType,
    this.recordedAt,
  });

  final String label;
  final double value;
  final String unit;
  final String icon;
  final String status;
  final String? sensorType;
  final DateTime? recordedAt;

  factory AreaEnvironmentMetric.fromJson(Map<String, dynamic> json) {
    return AreaEnvironmentMetric(
      label: (json['label'] ?? json['Label'] ?? '').toString(),
      value: (json['value'] ?? json['Value'] as num?)?.toDouble() ?? 0,
      unit: (json['unit'] ?? json['Unit'] ?? '').toString(),
      icon: (json['icon'] ?? json['Icon'] ?? 'sensor').toString(),
      status: (json['status'] ?? json['Status'] ?? 'good').toString(),
      sensorType: (json['sensorType'] ?? json['SensorType'])?.toString(),
      recordedAt: _parseDate(json['recordedAt'] ?? json['RecordedAt']),
    );
  }

  static DateTime? _parseDate(dynamic v) {
    if (v == null) return null;
    return DateTime.tryParse(v.toString());
  }
}

class AreaSensorLatestData {
  const AreaSensorLatestData({
    required this.areaId,
    required this.areaCode,
    required this.areaName,
    required this.scope,
    required this.inheritedByBox,
    required this.metrics,
    this.lastUpdatedAt,
    this.boxId,
    this.boxCode,
  });

  final String areaId;
  final String areaCode;
  final String areaName;
  final String scope;
  final bool inheritedByBox;
  final DateTime? lastUpdatedAt;
  final List<AreaEnvironmentMetric> metrics;
  final String? boxId;
  final String? boxCode;

  bool get isBoxInherited =>
      inheritedByBox && scope == 'box' && (boxId?.isNotEmpty ?? false);

  factory AreaSensorLatestData.fromJson(Map<String, dynamic> json) {
    final metricsJson = json['metrics'] ?? json['Metrics'];
    final list = metricsJson is List
        ? metricsJson
            .map((e) => AreaEnvironmentMetric.fromJson(e as Map<String, dynamic>))
            .toList()
        : <AreaEnvironmentMetric>[];

    return AreaSensorLatestData(
      areaId: (json['areaId'] ?? json['AreaId']).toString(),
      areaCode: (json['areaCode'] ?? json['AreaCode'] ?? '').toString(),
      areaName: (json['areaName'] ?? json['AreaName'] ?? '').toString(),
      scope: (json['scope'] ?? json['Scope'] ?? 'area').toString(),
      inheritedByBox: json['inheritedByBox'] ?? json['InheritedByBox'] ?? true,
      lastUpdatedAt: AreaEnvironmentMetric._parseDate(
        json['lastUpdatedAt'] ?? json['LastUpdatedAt'],
      ),
      boxId: (json['boxId'] ?? json['BoxId'])?.toString(),
      boxCode: (json['boxCode'] ?? json['BoxCode'])?.toString(),
      metrics: list,
    );
  }
}

/// Alias tương thích mock cũ.
typedef BoxEnvironmentMetric = AreaEnvironmentMetric;
