class FarmDashboardOverview {
  const FarmDashboardOverview({
    required this.healthScore,
    required this.alertCount,
    required this.devicesOnline,
    this.primaryAreaId,
    required this.summaryKpis,
    required this.kpiRow1,
    required this.kpiRow2,
    required this.statusSegments,
    required this.environmentParams,
    required this.alerts,
    required this.charts,
    required this.assistantHint,
    required this.statusMessage,
  });

  final int healthScore;
  final int alertCount;
  final String devicesOnline;
  final String? primaryAreaId;
  final List<DashboardKpiDto> summaryKpis;
  final List<DashboardKpiDto> kpiRow1;
  final List<DashboardKpiDto> kpiRow2;
  final List<DashboardStatusSegmentDto> statusSegments;
  final List<DashboardEnvParamDto> environmentParams;
  final List<DashboardAlertDto> alerts;
  final DashboardChartsDto charts;
  final String assistantHint;
  final String statusMessage;

  factory FarmDashboardOverview.fromJson(Map<String, dynamic> json) {
    List<T> list<T>(String key, T Function(Map<String, dynamic>) from) {
      final raw = json[key];
      if (raw is! List) return [];
      return raw
          .whereType<Map>()
          .map((e) => from(Map<String, dynamic>.from(e)))
          .toList();
    }

    return FarmDashboardOverview(
      healthScore: (json['healthScore'] as num?)?.toInt() ?? 0,
      alertCount: (json['alertCount'] as num?)?.toInt() ?? 0,
      devicesOnline: (json['devicesOnline'] ?? '0/0').toString(),
      primaryAreaId: (json['primaryAreaId'] ?? json['PrimaryAreaId'])?.toString(),
      summaryKpis: list('summaryKpis', DashboardKpiDto.fromJson),
      kpiRow1: list('kpiRow1', DashboardKpiDto.fromJson),
      kpiRow2: list('kpiRow2', DashboardKpiDto.fromJson),
      statusSegments: list('statusSegments', DashboardStatusSegmentDto.fromJson),
      environmentParams: list('environmentParams', DashboardEnvParamDto.fromJson),
      alerts: list('alerts', DashboardAlertDto.fromJson),
      charts: DashboardChartsDto.fromJson(
        json['charts'] is Map
            ? Map<String, dynamic>.from(json['charts'] as Map)
            : {},
      ),
      assistantHint: (json['assistantHint'] ?? '').toString(),
      statusMessage: (json['statusMessage'] ?? '').toString(),
    );
  }
}

class DashboardKpiDto {
  const DashboardKpiDto({
    required this.label,
    required this.value,
    this.badge,
    this.colorKey,
  });

  final String label;
  final String value;
  final String? badge;
  final String? colorKey;

  factory DashboardKpiDto.fromJson(Map<String, dynamic> json) => DashboardKpiDto(
        label: (json['label'] ?? '').toString(),
        value: (json['value'] ?? '').toString(),
        badge: json['badge']?.toString(),
        colorKey: json['colorKey']?.toString(),
      );
}

class DashboardStatusSegmentDto {
  const DashboardStatusSegmentDto({
    required this.label,
    required this.count,
    required this.colorKey,
  });

  final String label;
  final int count;
  final String colorKey;

  factory DashboardStatusSegmentDto.fromJson(Map<String, dynamic> json) =>
      DashboardStatusSegmentDto(
        label: (json['label'] ?? '').toString(),
        count: (json['count'] as num?)?.toInt() ?? 0,
        colorKey: (json['colorKey'] ?? 'healthy').toString(),
      );
}

class DashboardEnvParamDto {
  const DashboardEnvParamDto({
    required this.icon,
    required this.label,
    required this.value,
    required this.status,
  });

  final String icon;
  final String label;
  final String value;
  final String status;

  factory DashboardEnvParamDto.fromJson(Map<String, dynamic> json) =>
      DashboardEnvParamDto(
        icon: (json['icon'] ?? 'sensors').toString(),
        label: (json['label'] ?? '').toString(),
        value: (json['value'] ?? '').toString(),
        status: (json['status'] ?? 'good').toString(),
      );
}

class DashboardAlertDto {
  const DashboardAlertDto({required this.message, required this.severity});

  final String message;
  final String severity;

  factory DashboardAlertDto.fromJson(Map<String, dynamic> json) =>
      DashboardAlertDto(
        message: (json['message'] ?? '').toString(),
        severity: (json['severity'] ?? 'warning').toString(),
      );
}

class DashboardChartsDto {
  const DashboardChartsDto({
    required this.labels,
    required this.ph24h,
    required this.temp24h,
    required this.do24h,
    required this.growthBars,
    required this.batchHealth,
    required this.farmHealth,
  });

  final List<String> labels;
  final List<double> ph24h;
  final List<double> temp24h;
  final List<double> do24h;
  final List<double> growthBars;
  final List<DashboardBatchHealthSeriesDto> batchHealth;
  final List<double> farmHealth;

  factory DashboardChartsDto.fromJson(Map<String, dynamic> json) {
    List<double> nums(String key) {
      final raw = json[key];
      if (raw is! List) return [];
      return raw.map((e) => (e as num).toDouble()).toList();
    }

    final batchRaw = json['batchHealth'];
    final batches = batchRaw is List
        ? batchRaw
            .whereType<Map>()
            .map((e) => DashboardBatchHealthSeriesDto.fromJson(
                  Map<String, dynamic>.from(e),
                ))
            .toList()
        : <DashboardBatchHealthSeriesDto>[];

    final labelsRaw = json['labels'];
    final labels = labelsRaw is List
        ? labelsRaw.map((e) => e.toString()).toList()
        : <String>[];

    return DashboardChartsDto(
      labels: labels,
      ph24h: nums('ph24h'),
      temp24h: nums('temp24h'),
      do24h: nums('do24h'),
      growthBars: nums('growthBars'),
      batchHealth: batches,
      farmHealth: nums('farmHealth'),
    );
  }
}

class DashboardBatchHealthSeriesDto {
  const DashboardBatchHealthSeriesDto({required this.label, required this.values});

  final String label;
  final List<double> values;

  factory DashboardBatchHealthSeriesDto.fromJson(Map<String, dynamic> json) {
    final raw = json['values'];
    return DashboardBatchHealthSeriesDto(
      label: (json['label'] ?? '').toString(),
      values: raw is List ? raw.map((e) => (e as num).toDouble()).toList() : [],
    );
  }
}
